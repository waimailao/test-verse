import { Suspense } from 'react'
import { createBrowserRouter, createRoutesFromElements, Outlet, Route } from 'react-router-dom'
import Home from '../pages/Home'
import Layout from '../components/Layout'


function Root() {
  return (
    <Layout>
      <Suspense >
        <Outlet />
      </Suspense>
    </Layout>
  )
}

export const routes = createRoutesFromElements(
  <Route path="/" element={<Root />}>
    <Route path="" element={<Home />} />
  </Route>
)

export const router = createBrowserRouter(routes)
