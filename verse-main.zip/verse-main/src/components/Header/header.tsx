import clsx from "clsx";
import './header.css';
import { useEffect, useState } from "react";
import { MobileView, NotMView } from "../DeviceView";
import useMenuModal from "../MenuModal/useMenuModal";
import useWindowSize from "../../hooks/useWindowSize";
import navJson from "./json/nav.json";
import gsap from "gsap";
// import { useGSAP } from "@gsap/react";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ScrollToPlugin } from "gsap/ScrollToPlugin";

gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

const Header = () => {
    const { isMobile } = useWindowSize();

    // nav list
    const [navList] = useState(navJson);

    const [isScroll, setIsScroll] = useState(false);

    const onResize = () => {
        setIsScroll(document.documentElement.clientHeight < 768 && document.documentElement.clientWidth < 460);
    }

    useEffect(() => {
        onResize();
        window.addEventListener('resize', onResize);

        return () => {
            window.removeEventListener('resize', onResize);
        }
    }, [isMobile]);

    const { open } = useMenuModal();

    // build with us
    const handleBuild = () => {
        console.log("Build With Us");
    }

    // about us
    const handleAbout = () => {
        console.log("About Us");
    }

    return <div className={clsx(
        "header-container fixed z-[3000] flex w-full h-[120px] items-center justify-between py-[32px]",
        "px-[120px]",
        "md:px-[80px] md:py-[16px]",
        "sm:px-[60px]",
        "xs:px-[16px] xs:py-[4px] xs:h-[44px]",
    )}>
        <div className={clsx(
            "w-full flex items-center justify-between mx-[-14px] p-[14px] rounded-[100px] box-content",
            `${isScroll && !isMobile && "header-content"}`
        )}>
            <div className={clsx(
                "flex items-center gap-[100px]",
                "md:gap-[80px]",
                "sm:gap-[60px]"
            )}>
                <a href="#Home" className="nav-link">
                    <img src="/icons/logo.svg" className="cursor-pointer xs:w-[74px] xs:h-[24px]" />
                </a>
                <NotMView>
                    <nav className={clsx(
                        "flex gap-[32px]",
                        "md:gap-[28px]",
                        "sm:gap-[24px]"
                    )}>
                        {
                            navList.map((navItem: any) => {
                                return (
                                    <a key={navItem.id} href={`#${navItem.link}`} className={clsx(
                                        "nav-link link-line cursor-pointer text-[#0F0E0D]/80 font-meduim text-[14px] leading-[24px]"
                                    )}>
                                        {navItem.name}
                                    </a>
                                )
                            })
                        }

                    </nav>
                </NotMView>
            </div>

            <NotMView>
                <div className="flex gap-[24px]">
                    <div className={clsx(
                        "doc-btn flex items-center justify-center cursor-pointer text-[#EAE3D5]",
                        "font-bold text-[12px] gap-[12px] w-[130px] h-[36px] leading-[16px]",
                        "rounded-[100px] bg-[#0F0E0D] hover:bg-[#432A25] relative overflow-hidden select-none"
                    )}
                        onClick={handleBuild}
                    >
                        <span>Build With Us</span>
                        <img className="h-full absolute right-0 bottom-0 z-[0]" src="/images/hover_btn_bg.svg" alt="btn_bg" />
                    </div>

                    <div className={clsx(
                        "plain-btn flex items-center justify-center cursor-pointer",
                        "transition duration-500 ease-in-out hover:bg-[#89735E]/10",
                        "text-[#0F0E0D] text-[12px] w-[130px] leading-[16px] h-[36px] border border-[#0F0E0D]/80",
                        "rounded-[100px] relative overflow-hidden select-none"
                    )}
                        onClick={handleAbout}
                    >
                        <span className="z-[2]">About Us</span>
                    </div>
                </div>
            </NotMView>

            <MobileView>
                <div className="border border-black/20 w-[48px] h-[28px] rounded-[100px] flex items-center justify-center" onClick={open}>
                    <img src="/icons/menu.svg" className="" />
                </div>
            </MobileView>
        </div>
    </div>;
};

export default Header;
