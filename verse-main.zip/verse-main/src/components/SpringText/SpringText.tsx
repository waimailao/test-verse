import { useEffect } from 'react';
import { motion, useAnimation } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import clsx from 'clsx';

const SpringText = ({ text, size, center = false, delay = false, children }: { text: string, size?: number, center?: boolean, delay?: boolean, children?: any }) => {
    const controls = useAnimation();
    const [ref, inView] = useInView({
        triggerOnce: true, // once trigger animation
        threshold: 0.1, // 10% trigger animation
    });

    useEffect(() => {
        if (inView) {
            controls.start((i) => ({
                opacity: 1,
                y: 0,
                transition: { delay: delay ? i * 0.005 : 0, duration: 0.8 },
            }));
        }
    }, [controls, inView]);

    return (
        <div ref={ref} className={clsx(center && 'flex justify-center flex-wrap relative', size && `text-[${size}px]`)}>
            {children}
            {text.split('').map((char, index) => (
                <motion.span
                    key={index}
                    custom={index}
                    initial={{ opacity: 0, y: 50 }}
                    animate={controls}
                    style={{ display: 'inline-block', whiteSpace: 'pre', lineHeight: 1 }}
                >
                    {char === ' ' ? '\u00A0' : char}
                </motion.span>
            ))}
        </div>
    );
};

export default SpringText