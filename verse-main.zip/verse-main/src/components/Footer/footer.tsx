const footer = () => {
  return (
    <div></div>
  );
};

export default footer;
