import React, { useState, useEffect } from "react";
import Header from "../Header";
import Loading from "../Loading";
// import BgPin from "../BgPin";
import { motion } from "framer-motion";

const index = ({ children }: { children: React.ReactElement }) => {
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const timeout = setTimeout(() => {
            setLoading(false);
        }, 4200);
        return () => clearTimeout(timeout);
    }, [loading])

    return <div className="w-full h-full max-w-[1920px] mx-auto">
        {

            loading &&
            <motion.div animate={{ opacity: 0 }} transition={{ duration: 1, delay: 3 }} initial={{ opacity: 1 }}>
                <Loading />
            </motion.div>
            ||
            <>
                {/* <BgPin></BgPin> */}
                <Header />
                {children}
            </>
        }

    </div>;
};

export default index;
