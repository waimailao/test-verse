import "./loading.css";
import useWindowSize from "../../hooks/useWindowSize";

const index = () => {

    const { isMobile } = useWindowSize();

    return <div className="loading-container fixed z-[9999] w-full h-full max-w-[1920px] mx-auto px-[30px] py-[60px]">
        <div className="w-full h-full flex flex-wrap xs:hidden">
            <img className="w-[50%] h-full object-contain object-left" src="/images/left_border_figure.svg" alt="border_figure" />
            <img className="w-[50%] h-full object-contain object-right" src="/images/right_border_figure.svg" alt="border_figure" />
        </div>
        <div className="absolute w-full h-full z-[10] inset-0 flex flex-col justify-center items-center gap-[20px]">
            <div className="flex justify-center items-center">
                <img className="w-[165px] h-[165px] xs:w-[130px] xs:h-[130px] loading-rotate object-cover" src={isMobile ? "/icons/loading_rotate.png" : "/icons/loading_rotate.svg"} alt="loading_rotate" />
                <img className="w-[165px] h-[165px] xs:w-[130px] xs:h-[130px] object-cover absolute" src={isMobile ? "/icons/loading_logo.png" : "/icons/loading_logo.svg"} alt="loading_logo" />
            </div>
            <div className="loading-text text-[16px] flex gap-[40px] text-[#89735E]/0.5 mt-[20px] xs:gap-[26px] xs:text-[12px]">
                <span>L</span><span>O</span><span>A</span><span>D</span><span>I</span><span>N</span><span>G</span>
            </div>
            <div className="loading-text text-[20px] flex gap-[10px] text-[#89735E]/0.5 xs:text-[14px]">
                <span>.</span><span>.</span><span>.</span>
            </div>
        </div>
    </div>;
};

export default index;
