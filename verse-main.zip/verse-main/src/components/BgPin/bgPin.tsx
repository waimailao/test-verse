import "./bgPin.css";
import clsx from "clsx";

const index = () => {

    return <div className={clsx(
        "bg-container fixed z-[0] top-[0] left-[0] w-full h-full max-w-[1920px] mx-auto px-[30px] py-[60px]",
        "md:px-[20px]",
        "sm:px-[20px]",
        "xs:px-[8px] xs:py-[4px] xs:h-[44px]",
    )}>
        <div className="sticky t-[0] w-full h-full flex flex-wrap">
            <img className="w-[50%] h-full object-contain object-left" src="/images/left_border_figure.svg" alt="border_figure" />
            <img className="w-[50%] h-full object-contain object-right" src="/images/right_border_figure.svg" alt="border_figure" />
        </div>
    </div>;
};

export default index;
