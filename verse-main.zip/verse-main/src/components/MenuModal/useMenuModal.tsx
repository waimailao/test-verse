import { useModal } from "../Modal";
import navJson from "../Header/json/nav.json";
import { useState } from "react";
import clsx from "clsx";
import { useLocation } from "react-router-dom";

const useMenuModal = () => {
    const location = useLocation();

    const [navList] = useState(navJson);

    // build with us
    const handleBuild = () => {
        console.log("Build With Us");
    }

    // about us
    const handleAbout = () => {
        console.log("About Us");
    }

    const hideModal = () => {
        document.body.style.overflow = "";
    }

    const { open, close } = useModal({
        zIndex: 9000,
        content: <div className="flex flex-col">
            <div className="menus flex flex-col gap-[24px] pb-[30px] pt-[20px] px-[16px]">
                {
                    navList.map((navItem: any) => {
                        return (
                            <div key={navItem.id} className="flex">
                                <a href={`#${navItem.link}`} className={clsx(
                                    "nav-link link-line text-[16px] leading-[24px] h-[34px] flex items-center text-[#0F0E0D]/80 w-[auto]",
                                    `${location.hash == "#"+navItem.link ? "active" : ""}`
                                )} onClick={ () => { hideModal(); close(); } }>
                                    {navItem.name}
                                </a>
                            </div>
                        )
                    })
                }
            </div>
            <div className="flex flex-col gap-[23px] px-[12px] pt-[15px]">
                <div className={clsx(
                    "doc-btn flex items-center justify-center cursor-pointer text-[#EAE3D5]",
                    "font-bold text-[14px] gap-[12px] w-full h-[44px] leading-[16px]",
                    "rounded-[100px] bg-[#0F0E0D] hover:bg-[#432A25] relative overflow-hidden select-none"
                )}
                    onClick={handleBuild}
                >
                    <span>Build With Us</span>
                    <img className="h-full absolute right-0 bottom-0 z-[0]" src="/images/hover_btn_bg.svg" alt="btn_bg" />
                </div>

                <div className={clsx(
                    "plain-btn flex items-center justify-center cursor-pointer",
                    "transition duration-500 ease-in-out",
                    "text-[#0F0E0D] text-[14px] w-full h-[44px] leading-[16px] border border border-[#0F0E0D]/80",
                    "rounded-[100px] relative overflow-hidden select-none"
                )}
                    onClick={handleAbout}
                >
                    <span className="z-[2]">About Us</span>
                </div>
            </div>
        </div>
    })
    return {
        open, close
    };
};

export default useMenuModal;
