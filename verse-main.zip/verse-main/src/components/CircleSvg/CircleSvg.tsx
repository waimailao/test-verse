import { useEffect, useState } from 'react';
import useWindowSize from "../../hooks/useWindowSize";

const CircleSvg = () => {
  const [r1, setR1] = useState(120);
  const [r2, setR2] = useState(290);
  const [r3, setR3] = useState(520);
  const [r4, setR4] = useState(720);

  const { isMobile } = useWindowSize();

  useEffect(() => {
    if (isMobile) {
      setR1((prev: number) => {
        return prev * 2;
      });
      setR2((prev: number) => {
        return prev * 2;
      });
      setR3((prev: number) => {
        return prev * 2;
      });
      setR4((prev: number) => {
        return prev * 2;
      });
    }
  }, [isMobile, r1, r2, r3, r4]);

  return (
    <div className='flex justify-center'>
      <svg width="1440" height="911" viewBox="0 0 1440 911" fill="none" id="circles">
        <g transform={isMobile ? "translate(720 155)" : "translate(720 455)"}>
          {/* line-1 */}
          <circle r={r1} data-radius="230" stroke="#89735E" className="js-main-circle" opacity="1" strokeWidth="2" strokeDasharray="2 26">
            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="360" to="0" dur="25s" repeatCount="indefinite"></animateTransform>
          </circle>
          {/* line-2 */}
          <circle r={r2} data-radius="400" stroke="#89735E" className="js-main-circle" opacity="0.8" strokeWidth="2" strokeDasharray="2 26">
            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="0" to="360" dur="45s" repeatCount="indefinite"></animateTransform>
          </circle>
          {/* line-3 */}
          <circle r={r3} data-radius="588" stroke="#89735E" className="js-main-circle" opacity="0.6" strokeWidth="2" strokeDasharray="2 26">
            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="360" to="0" dur="65s" repeatCount="indefinite"></animateTransform>
          </circle>
          <circle r={r4} data-radius="720" stroke="#89735E" className="js-main-circle" opacity="0.5" strokeWidth="2" strokeDasharray="2 26">
            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="0" to="360" dur="85s" repeatCount="indefinite"></animateTransform>
          </circle>
        </g>
      </svg>
    </div>
  );
};

export default CircleSvg;
