/* eslint-disable @typescript-eslint/no-explicit-any */

import useWindowSize from "../../hooks/useWindowSize"

export const BrowserView = ({ children }: { children: any }) => {
    const { width } = useWindowSize()
    const isBrowser = width > 1280

    return isBrowser ? <>{children}</> : null
}
export const NotMView = ({ children }: { children: any }) => {
    const { width } = useWindowSize()
    const isBrowser = width > 768

    return isBrowser ? <>{children}</> : null
}
export const MdView = ({ children }: { children: any }) => {
    const { width } = useWindowSize()
    const isMd = width <= 1280

    return isMd ? <>{children}</> : null
}

export const MobileView = ({ children }: { children: any }) => {
    const { width } = useWindowSize()
    const isMobile = width <= 768

    return isMobile ? <>{children}</> : null
}
