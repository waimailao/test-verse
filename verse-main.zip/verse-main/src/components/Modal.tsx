import { ReactNode, useEffect, useRef, useState } from 'react';
import { useModal as _useModal } from 'react-modal-hook';
import pDefer from 'p-defer';
import clsx from 'clsx';

function Modal({
  content,
  width,
  close,
  zIndex = 9999,
  showClose = false
}: {
  content: ReactNode;
  width?: number;
  close: () => void;
  zIndex?: number;
  showClose?: boolean;
}) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    setTimeout(() => {
      setShow(true);
    }, 200);
  }, []);

  // eslint-disable-next-line no-extra-boolean-cast
  const style = !!zIndex
    ? { width: `${width}px`, zIndex }
    : { width: `${width}px` };

  return (
    <div
      style={style}
      className={clsx(
        'common-bg w-[60%] h-full fixed z-[9200] top-1/2 left-[0] -translate-y-1/2 bg-dark-modal z-[800] pb-[24px] transition-all duration-400 invisible opacity-0',
        show ? '!opacity-100 !visible' : '',
      )}
    >
      <div
        className={clsx(
          'text-white-text flex items-center w-full'
        )}
      >
        <a href="#Home" className="nav-link w-full h-[56px] flex items-center justify-between p-[14px]">
          <img src="/icons/logo.svg" className="w-[74px] h-[24px]" />
        </a>
        {showClose && (
          <img
            src="/icons/close.svg"
            width={20}
            height={20}
            alt=""
            onClick={close}
            className="cursor-pointer xs:w-[16px] xs:h-[16px] w-[20px] h-[20px]"
          />
        )}
      </div>
      {content}
    </div>
  );
}

export const useModal = ({
  content,
  width,
  zIndex,
  showClose = false,
  maskClose = true,
}: {
  content: ReactNode;
  width?: number;
  zIndex?: number;
  showClose?: boolean;
  maskClose?: boolean;
}) => {
  const deferred = useRef(pDefer<boolean>());

  const close = () => {
    // if (!showClose) {
    //   return;
    // }
    deferred.current.resolve(false);

    hideModal();

    deferred.current = pDefer<boolean>();

    document.body.style.overflow = "";
  };

  const [showModal, hideModal] = _useModal(
    ({ in: open }) => (
      <>
        {open && (
          <div
            className="fixed top-0 left-0 w-full h-full z-[5000] bg-black/70 backdrop-blur-[5px]"
            onClick={() => {
              if (maskClose)
                close()
            }}
          ></div>
        )}
        {open && (
          <Modal
            content={content}
            width={width}
            close={close}
            zIndex={zIndex}
            showClose={showClose}
          />
        )}
      </>
    ),
    [content, width, zIndex, showClose]
  );

  return {
    open: showModal,
    close: hideModal,
    deferred,
  };
};
