import { useEffect, useState } from 'react'

export default function useWindowSize(): { height: number; width: number; isMobile: boolean } {
    const [size, setSize] = useState({
        width: 0,
        height: 0,
        isMobile: false
    })

    const onResize = () => {
        setSize({
            width: document.documentElement.clientWidth,
            height: document.documentElement.clientHeight,
            isMobile: document.documentElement.clientWidth <= 768
        })
    }

    useEffect(() => {
        onResize()
        window.addEventListener('resize', onResize)

        return () => {
            window.removeEventListener('resize', onResize)
        }
    }, [])

    return size
}
