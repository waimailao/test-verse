import clsx from "clsx";
import "./economic.css";
import { useRef } from "react";
import useWindowSize from "../../../../hooks/useWindowSize";
import SpringText from "../../../../components/SpringText";
import BgPin from "../../../../components/BgPin";
import CircleSvg from "../../../../components/CircleSvg";
import { useGSAPContext } from '../../GSAPContext';
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
gsap.registerPlugin(ScrollTrigger);

const Economic = () => {
    const { isMobile } = useWindowSize();

    const { gsapInstance } = useGSAPContext();

    const title = useRef<HTMLDivElement>(null);
    const subTitle = useRef<HTMLDivElement>(null);
    const economicRef = useRef<HTMLDivElement>(null);

    useGSAP(() => {
        const media = window.matchMedia("screen and (max-width: 768px)");

        const showImage = document.querySelector(".show-img-wrap");

        const tl = gsapInstance.timeline({
            scrollTrigger: {
                trigger: economicRef.current,
                // start: "top top",
                // end: "top bottom",
                start: media.matches ? `${3.6 * innerHeight} top` : `${3.6 * innerHeight} top`,
                end: media.matches ? `${4.5 * innerHeight}` : `${4.5 * innerHeight} ${innerHeight / 2}`,
                scrub: 1,
                // markers: {
                //     startColor: "blue",
                //     endColor: "blue",
                //     indent: 100
                // },
            }
        });
        tl.fromTo(title.current, { y: 30, autoAlpha: 0 }, { autoAlpha: 1, y: 0, duration: .3 })
            .fromTo(subTitle.current, { y: 30, autoAlpha: 0 }, { autoAlpha: 1, y: 0, duration: .3 })
            .from(showImage, { opacity: 0, duration: 0.3 });
    }, {
        scope: economicRef
    });

    return <div ref={economicRef} className="economic-container common-bg relative w-full h-full flex items-center xs:h-full xs:py-[40px]">
        <div className={clsx(
            "relative z-[2] w-full h-full max-h-[60%] flex flex-col gap-[20px] justify-center",
            "px-[120px]",
            "md:px-[80px]",
            "sm:px-[60px]",
            "xs:px-[16px]"
        )}>
            <div ref={title} className={clsx(
                "title text-[80px] font-bold leading-1 font-BD_Regular",
                "xs:text-[32px]"
            )}>
                <SpringText text="Decentralized" center />
                <SpringText text="Creator Economic" center />
            </div>
            <div ref={subTitle} className={clsx(
                "sub-title flex flex-col gap-[4px] text-[16px] leading-[24px] w-[40%] mx-auto text-[#0F0E0D]/60",
                "xs:text-[12px] xs:w-[90%]"
            )}>
                <SpringText text="Here is a description copy，Here is a description " center />
                <SpringText text="copy，Here is a description copy" center />
            </div>
            <div className="show-img-wrap flex justify-center mt-[30px] relative opacity-1">
                <img className="w-[78%] object-cover" src={isMobile ? "/images/home/economic_img_m.png" : "/images/home/economic_img.png"} alt="bg" />
            </div>
        </div>
        {
            !isMobile && <div className={clsx(
                "absolute top-0 z-[1] w-full h-full",
                "px-[34px]",
                "md:px-[24px]",
                "sm:px-[24px]",
                "xs:hidden"
            )}>
                <CircleSvg />
            </div>
        }
        <div className={clsx(
            "absolute top-0 z-[0] w-full h-full",
            "px-[34px]",
            "md:px-[24px]",
            "sm:px-[24px]",
            "xs:hidden"
        )}>
            <BgPin />
        </div>
    </div>
};

export default Economic;
