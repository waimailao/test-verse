import clsx from "clsx";
import useWindowSize from "../../../../hooks/useWindowSize";
// import { useEffect } from "react";
import SpringText from "../../../../components/SpringText";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
import { useRef } from "react";
import { useGSAPContext } from '../../GSAPContext';
import BgPin from "../../../../components/BgPin";
import "./Classify.css";
gsap.registerPlugin(ScrollTrigger);

const Classify = () => {
    const { isMobile } = useWindowSize();

    const textList = [
        {
            title: "Read",
            subTitle: "Pioneering the gaming blockchain on Cosmos with EVM or any-VM compatibility."
        },
        {
            title: "Write",
            subTitle: "Pioneering the gaming blockchain on Cosmos with EVM or any-VM compatibility."
        },
        {
            title: "Own",
            subTitle: "Pioneering the gaming blockchain on Cosmos with EVM or any-VM compatibility."
        },
        {
            title: "Genesis",
            subTitle: "Pioneering the gaming blockchain on Cosmos with EVM or any-VM compatibility."
        }
    ];

    // image position progress
    let titleMap = [
        [0, 0.21],
        [0.21, 0.39],
        [0.4, 0.60],
        [0.61, 1],
    ];

    const scrollImageRef = useRef<HTMLImageElement>(null);
    const classifyRef = useRef<HTMLDivElement>(null);

    const { gsapInstance } = useGSAPContext();

    useGSAP(() => {
        const textWraps: any = [...gsap.utils.toArray(".text-wrap")];
        const titles: any = [...gsap.utils.toArray(".title")];
        const subTitles: any = [...gsap.utils.toArray(".sub-title")];

        const media = window.matchMedia("screen and (max-width: 768px)");

        if (!media.matches) {
            const resetState = () => {
                textList.forEach((_, i: number) => {
                    if (titles[i]) gsap.to(titles[i], { color: "#BCB1A6", duration: 0.8 });
                    if (subTitles[i]) gsap.to(subTitles[i], { y: 80, opacity: 0, height: 0, duration: 0.8 });
                })
            }
            
            const tl = gsapInstance.timeline({
                scrollTrigger: {
                    trigger: classifyRef.current,
                    // start: `top top`,
                    // end: `+=3000 bottom`,
                    start: `${innerHeight * 0.5} top`,
                    end: `${innerHeight + innerHeight / 2}`,
                    scrub: 1,
                    // markers: {
                    //     startColor: "blue",
                    //     endColor: "blue",
                    //     indent: 100
                    // },
                    onUpdate: (self: any) => {
                        const dis = self.progress;
                        titleMap.forEach((item: number[], index: number) => {
                            if (dis >= item[0] && dis <= item[1]) {
                                if (titles[index]) gsap.to(titles[index], { color: index == titleMap.length - 1 ? "#E26655" : "#000", duration: 0.8 });
                                if (subTitles[index]) gsap.to(subTitles[index], { y: 0, opacity: 1, height: "auto", duration: 0.8 });
                            } else {
                                if (titles[index]) gsap.to(titles[index], { color: "#BCB1A6", duration: 0.8 });
                                if (subTitles[index]) gsap.to(subTitles[index], { y: 80, opacity: 0, height: 0, duration: 0.8 });
                            }
                        });
                    },
                    onLeave: () => resetState(),
                    onLeaveBack: () => resetState()
                }
            });

            tl.to(scrollImageRef.current, { right: "28%" });
        } else {
            const scrollTween = gsapInstance.to(textWraps, {
                xPercent: -100 * (textWraps.length - 1),
                ease: "none",
                scrollTrigger: {
                    trigger: classifyRef.current,
                    start: `${innerHeight * 0.8} top`,
                    // pin: true,
                    scrub: 1,
                    end: `+=${textList.length * 100}vw`
                }
            });
            titles.forEach((title: HTMLElement, index: number) => {
                gsapInstance.to(title, {
                    color: index == titles.length - 1 ? "#E26655" : "#000",
                    ease: "none",
                    scrollTrigger: {
                        trigger: title,
                        containerAnimation: scrollTween,
                        start: "top 80%",
                        end: "bottom 20%",
                        // scrub: true
                    }
                });
            });
            const tl = gsapInstance.timeline({
                scrollTrigger: {
                    trigger: classifyRef.current,
                    start: `${innerHeight * 0.8} top`,
                    end: `+=${textList.length * 100}vw`,
                    scrub: 1
                }
            });
            tl.set(scrollImageRef.current, {
                x: "0"
            });
            tl.to(scrollImageRef.current, {
                ease: "none",
                x: () => {
                    const scrollWidth = scrollImageRef.current?.getBoundingClientRect().width || 0;
                    return "-" + (scrollWidth - document.documentElement.clientWidth) + "px"
                }
            });
        }
    }, {
        scope: classifyRef
    });

    return (
        <div ref={classifyRef} className="classify-container common-bg relative w-full h-full">
            <div className={clsx(
                "relative z-[10] w-full h-full max-h-[100%] flex flex-col",
                "px-[120px]",
                "md:px-[80px]",
                "sm:px-[60px]",
                "xs:px-[16px]"
            )}>
                <div className={clsx(
                    `h-full flex flex-col justify-center gap-[24px]`,
                    `xs:flex-row xs:w-full xs:justify-start xs:gap-[0] xs:overflow-hidden`
                )}>
                    {
                        textList.map((text: any) => {
                            return (
                                <div className={clsx(
                                    "text-wrap flex flex-col max-w-[390px]",
                                    "xs:flex-none xs:h-[100vh] xs:w-full xs:max-w-[100%] xs:justify-end xs:pb-[80px]"
                                )} key={text.title}>
                                    <div className={clsx(
                                        "title text-[100px] leading-[100px] text-[#BCB1A6] font-BD_Regular",
                                        "md:text-[90px]",
                                        "sx:text-[80px]",
                                        "xs:text-[48px]"
                                    )}>
                                        <SpringText text={text.title} />
                                    </div>
                                    <div className={clsx(
                                        "sub-title flex flex-col gap-[30px] text-[14px] h-[0] opacity-[0] transform3d(0, 80px, 0)",
                                        "xs:gap-[20px] xs:text-[12px] xs:h-[auto] xs:opacity-[1] xs:transform3d(0, 0, 0)"
                                    )}>
                                        <img className="-rotate-90 w-[8px]" src="/icons/arrow_down.svg" alt="arrow" />
                                        <span className="w-[90%]">{text.subTitle}</span>
                                        <img className="w-[176px]" src="/images/home/home_line.svg" alt="line" />
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
            <div className={clsx(
                "relative top-[-100%] z-[1] w-full h-full",
                "px-[34px]",
                "md:px-[24px]",
                "sm:px-[24px]",
                "xs:hidden"
            )}>
                <BgPin />
            </div>
            <div className={clsx(
                "absolute top-0 w-full h-full",
                "px-[34px]",
                "md:px-[24px]",
                "sm:px-[24px]",
                "xs:px-[12px]"
            )}>
                <div className={clsx(
                    "relative w-full h-full flex flex-wrap items-center overflow-hidden"
                )}>
                    <img ref={scrollImageRef} src={isMobile ? "/images/home/scroll_star_m.png" : "/images/home/scroll_star.png"} alt="bg" className={clsx(
                        "absolute right-[-80%]",
                        "xs:h-[90vh] xs:max-w-none xs:top-[0] xs:right-[auto] xs:transform3d(0, 0, 0)"
                    )} />
                    <img src={isMobile ? "/images/home/filter_bg_m.png" : "/images/home/filter_bg.png"} alt="bg" className={clsx(
                        "relative top-[0] left-[0] w-full object-cover opacity-[0.8]",
                        "xs:absolute xs:h-[90vh] xs:top-[0] xs:max-w-none"
                    )} />
                </div>
            </div>
        </div>
    )
};

export default Classify;
