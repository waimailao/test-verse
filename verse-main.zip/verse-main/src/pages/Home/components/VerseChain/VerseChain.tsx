import clsx from "clsx";
import useWindowSize from "../../../../hooks/useWindowSize";
import SpringText from "../../../../components/SpringText";
import BgPin from "../../../../components/BgPin";
import './verseChain.css';
const VerseChain = () => {
    const { isMobile } = useWindowSize();

    // build with us
    const handleBuild = () => {
        console.log("Build With Us")
    }

    return <div className="verse-chain-container common-bg relative w-full h-full flex items-center">
        <div className={clsx(
            "relative z-[1] w-full h-full flex flex-col gap-[46px] justify-center overflow-hidden",
            "px-[120px]",
            "md:px-[80px]",
            "sm:px-[60px]",
            "xs:px-[16px] xs:mt-[0] xs:gap-[20px]"
        )}>
            <div className={clsx(
                "absolute z-[-1] left-0 top-0 w-full h-full flex justify-center items-center",
                "xs:w-[100%]"
            )}>
                {
                    isMobile ?
                        <img src="/video/home_chain_bg_m.webp" className="absolute bottom-0 left-0 w-full h-full object-cover" />
                        :
                        <video src={"/video/home_chain_bg.mp4"} className="w-full h-full object-cover object-center" autoPlay muted loop />
                }
                <img src={isMobile ? "/images/home/video_modal_m.png" : "/images/home/video_modal.png"} className="absolute bottom-0 left-0 w-full h-full object-cover" />
            </div>

            <div className={clsx(
                "absolute top-0 z-[-1] w-full h-full",
                "px-[34px]",
                "md:px-[24px]",
                "sm:px-[24px]",
                "xs:hidden"
            )}>
                <BgPin />
            </div>

            <div className="flex justify-center">
                <img className="object-cover w-[20px] xs:hidden" src="/icons/chain/double_arrow.svg" alt="arrow" />
            </div>

            <div className={clsx(
                "text-[80px] font-bold leading-1 flex gap-[24px] justify-center font-BD_Regular relative",
                "xs:text-[54px]"
            )}>
                <img className="object-contain xs:hidden" src="/images/home/left_dot.png" alt="dot" />
                <SpringText text="Verse Chain" center>
                    { isMobile && <img src="/icons/chain/bottom_v_logo.svg" className="absolute top-[-96%] left-[-16px]" alt="v_logo" /> }
                </SpringText>
                <img className="object-contain xs:hidden" src="/images/home/right_dot.png" alt="dot" />
            </div>

            <div className="flex justify-center gap-[20px]">
                <div className="text-[45px] rotate-20 xs:hidden font-BD_Regular">
                    <SpringText text="{" center />
                </div>
                <div className={clsx(
                    "flex flex-col gap-[4px] text-[24px] leading-[24px] text-[#0F0E0D]",
                    "xs:text-[16px] xs:w-[90%]"
                )}>
                    <SpringText text="Enjoy the Real Permissionless " center />
                    <SpringText text="in Verse" center />
                </div>
                <div className="text-[45px] rotate-20 xs:hidden font-BD_Regular">
                    <SpringText size={45} text="}" center />
                </div>
            </div>

            <div className="flex justify-center mt-[30px] xs:mt-[0] xs:mb-[20%]">
                <div className={clsx(
                    "doc-btn flex items-center justify-center cursor-pointer text-[#EAE3D5]",
                    "font-bold text-[14px] gap-[12px] w-[190px] h-[44px] leading-[16px]",
                    "rounded-[100px] bg-[#0F0E0D] hover:bg-[#432A25] relative overflow-hidden select-none",
                )}
                    onClick={handleBuild}
                >
                    <span>Build With Us</span>
                    <img className="h-full absolute right-0 bottom-0 z-[0]" src="/images/hover_btn_bg.svg" alt="btn_bg" />
                </div>
            </div>

            <div className={clsx(
                "flex items-center justify-center mt-[60px] xs:absolute xs:bottom-[60px] xs:mt-[0] xs:left-[50%] xs:-translate-x-1/2"
            )}>
                <div className="flex items-center justify-center gap-[32px]">
                    <div className={clsx(
                        "w-[66px] h-[66px] rounded-[99px] border border-[#89735E80] bg-[#89735E]/10 hover:bg-[#89735E]/40"
                    )}>
                        <a className={clsx(
                            "w-full h-full flex items-center justify-center"
                        )} href="#">
                            <img src="/icons/chain/link1.svg" alt="link" />
                        </a>
                    </div>
                    <div className={clsx(
                        "w-[66px] h-[66px] rounded-[99px] border border-[#89735E80] bg-[#89735E]/10 hover:bg-[#89735E]/40"
                    )}>
                        <a className={clsx(
                            "w-full h-full flex items-center justify-center"
                        )} href="#">
                            <img src="/icons/chain/link2.svg" alt="link" />
                        </a>
                    </div>
                    <div className={clsx(
                        "w-[66px] h-[66px] rounded-[99px] border border-[#89735E80] bg-[#89735E]/10 hover:bg-[#89735E]/40"
                    )}>
                        <a className={clsx(
                            "w-full h-full flex items-center justify-center"
                        )} href="#">
                            <img src="/icons/chain/link3.svg" alt="link" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>;
};

export default VerseChain;
