import { useRef, useState } from 'react';
import clsx from 'clsx';
import infoJson from "./json/info.json";
import "./modulesDot.css";
import BgPin from '../../../../components/BgPin';
import { useGSAPContext } from '../../GSAPContext';
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useGSAP } from "@gsap/react";
gsap.registerPlugin(ScrollTrigger);

const App = () => {
    const { gsapInstance } = useGSAPContext();
    const [isMobile, setIsMobile] = useState(false);

    const [r1, setR1] = useState(120);
    const [r2, setR2] = useState(290);
    const [r3, setR3] = useState(520);
    const [r4, setR4] = useState(720);

    const [strokeWidth, setStrokeWidth] = useState(2);

    const [list] = useState(infoJson);

    const speed = [0.25, 0.4, 0.75, 1];

    const dotRef = useRef<HTMLDivElement>(null);
    const svgRef = useRef<SVGSVGElement>(null);

    useGSAP(() => {
        const cards: any = [...gsapInstance.utils.toArray(".modules-card")];
        const modules: any = [...gsapInstance.utils.toArray(".modules-dot")];
        const moduleTitles: any = [...gsapInstance.utils.toArray(".modules-title")];
        const moduleImgs: any = [...gsapInstance.utils.toArray(".modules-img")];

        const media = window.matchMedia("screen and (max-width: 768px)");
        setIsMobile(media.matches);

        if (!isMobile) {
            //  update position
            const updateDivPosition = (point: HTMLElement, div: HTMLElement) => {
                const rect = point.getBoundingClientRect();
                div.style.left = rect.left + 40 + 'px';
                div.style.top = rect.top - 10 + 'px';
            }

            // get dot position sort: [3, 2, 4, 1]
            const firstDot = svgRef.current?.querySelector('#firstDot');
            const secondDot = svgRef.current?.querySelector('#secondDot');
            const thirdDot = svgRef.current?.querySelector('#thirdDot');
            const fourdDot = svgRef.current?.querySelector('#fourdDot');
            const dots = [thirdDot, secondDot, fourdDot, firstDot];
            modules.forEach((module: any, index: number, arr: any[]) => {
                const tl = gsapInstance.timeline({
                    scrollTrigger: {
                        trigger: dotRef.current,
                        // start: `${3 * innerHeight - innerHeight / 2} top`,
                        // end: `${3 * innerHeight + innerHeight / 2}`,
                        scrub: 1,
                        // markers: {
                        //     startColor: "blue",
                        //     endColor: "blue",
                        //     indent: 100
                        // },
                        onToggle: self => self.isActive && updateDivPosition(dots[index] as HTMLElement, module)
                    }
                });

                tl.to(moduleTitles[index], { autoAlpha: 1, duration: 1 }, "<");
                tl.to(moduleImgs[index], { autoAlpha: 1, duration: 1 }, "<");

                module.addEventListener('mousemove', () => {
                    arr.forEach((_, i: number) => {
                        gsapInstance.to(moduleTitles[i], { opacity: 0.5 });
                        gsapInstance.to(moduleImgs[i], { opacity: 0.5 });
                    })
                    gsapInstance.to(moduleTitles[index], { autoAlpha: 1 });
                    gsapInstance.to(moduleImgs[index], { autoAlpha: 1 });
                    gsapInstance.to(cards[index], { autoAlpha: 1, duration: 0 });
                });
                module.addEventListener('mouseleave', () => {
                    arr.forEach((_, i: number) => {
                        gsapInstance.to(moduleTitles[i], { opacity: 1 });
                        gsapInstance.to(moduleImgs[i], { opacity: 1 });
                    })
                    gsapInstance.to(cards[index], { autoAlpha: 0 });
                });

                return () => {
                    module.removeEventListener('mousemove');
                    module.removeEventListener('mouseleave');
                }
            });
        } else {
            setR1((prev: number) => {
                return prev * 2;
            });
            setR2((prev: number) => {
                return prev * 2;
            });
            setR3((prev: number) => {
                return prev * 2;
            });
            setR4((prev: number) => {
                return prev * 2;
            });
            setStrokeWidth((prev: number) => {
                return prev * 2
            });
            const timer = setTimeout(() => {
                gsapInstance.to(modules, {
                    xPercent: -100 * (list.length - 1) - 14,
                    ease: "none",
                    scrollTrigger: {
                        trigger: dotRef.current,
                        scrub: 1,
                        start: `${innerHeight * 2.8} top`,
                        end: `+=${list.length * 100}vw`,
                        // markers: {
                        //     startColor: "blue",
                        //     endColor: "blue",
                        //     indent: 100
                        // }
                    }
                });
            }, 200);
            return () => {
                clearTimeout(timer);
            }
        }
    }, {
        dependencies: [dotRef, svgRef, isMobile], scope: dotRef
    });

    return (
        <div ref={dotRef} className="dot-container common-bg relative w-full h-full">
            <div className={clsx(
                "relative z-[10] w-full h-full flex flex-col justify-center",
                "px-[120px] py-[120px]",
                "md:px-[80px] md:py-[80px]",
                "sm:px-[60px] sm:py-[60px]",
                "xs:px-[16px] xs:py-[16px] xs:overflow-hidden"
            )}>
                <div className="modlues-list w-full h-full xs:flex xs:overflow-hidden xs:gap-[14px]">
                    {
                        // pc
                        !isMobile && list.map((item: any, i: number) => {
                            return (
                                <div className={clsx(
                                    "modules-dot absolute z-[10] box-border flex flex-col justify-start items-start cursor-pointer",
                                    "xs:w-full xs:flex-none xs:top-[0]"
                                )}
                                    id={`modulesDot${i}`}
                                    data-scrub={speed[i]}
                                    key={item.icon}
                                >
                                    <div className="modules-title text-[#89735E] text-[32px] font-bold font-BD_Medium opacity-[1]">
                                        <span>{item.title}</span>
                                    </div>
                                    <div className="flex items-center justify-start">
                                        <div className="modules-img w-[306px] aspect-[306/224] ml-[-10%] opacity-[1]">
                                            <img className="w-full h-full object-cover" src={`/icons/modules/${item.icon}.png`} alt="modules" />
                                        </div>
                                        <div className="modules-card w-[338px] px-[20px] py-[16px]">
                                            <div className="mb-[12px] text-[12px] text-[#89735E]">
                                                {item.content}
                                            </div>
                                            <div className={clsx(
                                                "plain-btn flex items-center gap-[4px] justify-center cursor-pointer",
                                                "transition duration-500 ease-in-out hover:bg-[#89735E]/10",
                                                "text-[#89735E] text-[12px] w-[110px] leading-[16px] h-[36px] border border-[#89735E]/80",
                                                "rounded-[100px] relative overflow-hidden select-none"
                                            )}
                                            >
                                                <span className="z-[2]">view more</span>
                                                <div className="button-box">
                                                    <span className="button-elem"><img src="/icons/modules/arrow.svg" alt="arrow" /></span>
                                                    <span className="button-elem"><img src="/icons/modules/arrow.svg" alt="arrow" /></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                    {
                        // mobile
                        isMobile && list.map((item: any, i: number) => {
                            return (
                                <div className={clsx(
                                    "modules-dot box-border h-ull flex flex-col justify-center items-start cursor-pointer",
                                    "xs:w-full xs:flex-none xs:top-[0]"
                                )}
                                    id={`modulesDot${i}`}
                                    data-scrub={speed[i]}
                                    key={item.icon}
                                >
                                    <div className="text-[#89735E] text-[24px] font-bold font-BD_Medium opacity-[1]">
                                        <span>{item.title}</span>
                                    </div>
                                    <div className="flex flex-col items-center justify-start">
                                        <div className="modules-card w-full px-[20px] py-[16px] xs:!opacity-[1] xs:!visible">
                                            <div className="mb-[12px] text-[12px] text-[#89735E]">
                                                {item.content}
                                            </div>
                                            <div className={clsx(
                                                "plain-btn flex items-center gap-[4px] justify-center cursor-pointer",
                                                "transition duration-500 ease-in-out hover:bg-[#89735E]/10",
                                                "text-[#89735E] text-[12px] w-[110px] leading-[16px] h-[36px] border border-[#89735E]/80",
                                                "rounded-[100px] relative overflow-hidden select-none"
                                            )}
                                            >
                                                <span className="z-[2]">view more</span>
                                                <div className="button-box">
                                                    <span className="button-elem"><img src="/icons/modules/arrow.svg" alt="arrow" /></span>
                                                    <span className="button-elem"><img src="/icons/modules/arrow.svg" alt="arrow" /></span>
                                                </div>
                                            </div>
                                            <div className="w-[306px] aspect-[306/224] ml-[-10%] opacity-[1]">
                                                <img className="w-full h-full object-cover" src={`/icons/modules/${item.icon}.png`} alt="modules" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
            {/* svg animation */}
            <div className="relative z-[0] top-[-100%] flex justify-center">
                <svg ref={svgRef} width="1440" height="911" viewBox="0 0 1440 911" fill="none" id="circles">
                    <g transform={isMobile ? "translate(720 155)" : "translate(720 455)"}>
                        {/* line-1 */}
                        <circle r={r1} data-radius="230" stroke="#89735E" className="js-main-circle" opacity="1" strokeWidth={strokeWidth} strokeDasharray={`${strokeWidth} 26`}>
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="360" to="0" dur="25s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        {/* line-2 */}
                        <circle r={r2} data-radius="400" stroke="#89735E" className="js-main-circle" opacity="0.8" strokeWidth={strokeWidth} strokeDasharray={`${strokeWidth} 26`}>
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="0" to="360" dur="45s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        {/* line-3 */}
                        <circle r={r3} data-radius="588" stroke="#89735E" className="js-main-circle" opacity="0.6" strokeWidth={strokeWidth} strokeDasharray={`${strokeWidth} 26`}>
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="360" to="0" dur="65s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle r={r4} data-radius="720" stroke="#89735E" className="js-main-circle" opacity="0.5" strokeWidth={strokeWidth} strokeDasharray={`${strokeWidth} 26`}>
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="0" to="360" dur="85s" repeatCount="indefinite"></animateTransform>
                        </circle>

                        {/* line-1-dot1 */}
                        <circle className="dot1" id="firstDot" cy={-r1} r="7" fill="#89735E" transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="145" to="145" dur="0s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle className="dot1" cy={-r1} r="12" fill="#89735E" opacity="0.3" strokeWidth={strokeWidth} transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="145" to="145" dur="0s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle className="dot1" r={14} cy={-r1} data-radius="14" stroke="#89735E" opacity="0.3" strokeWidth="1" transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="145" to="145" dur="0s" repeatCount="indefinite"></animateTransform>
                            <animate attributeName="r" values="4;28;" dur="6s" repeatCount="indefinite"></animate>
                            <animate attributeName="stroke" values="#89735E;transparent" dur="6s" repeatCount="indefinite"></animate>
                        </circle>
                        {/* line-2-dot1 */}
                        <circle className="dot2" id="secondDot" cy={-r2} r="7" fill="#89735E" transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="36" to="36" dur="0s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle className="dot2" cy={-r2} r="12" fill="#89735E" opacity="0.3" strokeWidth={strokeWidth} transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="36" to="36" dur="0s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle className="dot2" r={14} cy={-r2} data-radius="14" stroke="#89735E" opacity="0.3" strokeWidth="1" transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="36" to="36" dur="0s" repeatCount="indefinite"></animateTransform>
                            <animate attributeName="r" values="4;32;" dur="6s" repeatCount="indefinite"></animate>
                            <animate attributeName="stroke" values="#89735E;transparent" dur="6s" repeatCount="indefinite"></animate>
                        </circle>
                        {/* line-3-dot1 */}
                        <circle className="dot3" id="thirdDot" cy={-r3} r="7" fill="#89735E" transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="300" to="300" dur="0s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle className="dot3" cy={-r3} r="12" fill="#89735E" opacity="0.3" strokeWidth={strokeWidth} transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="300" to="300" dur="0s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle className="dot3" r={14} cy={-r3} data-radius="14" stroke="#89735E" opacity="0.3" strokeWidth="1" transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="300" to="300" dur="0s" repeatCount="indefinite"></animateTransform>
                            <animate attributeName="r" values="4;34;" dur="6s" repeatCount="indefinite"></animate>
                            <animate attributeName="stroke" values="#89735E;transparent" dur="6s" repeatCount="indefinite"></animate>
                        </circle>
                        {/* line-3-dot2 */}
                        <circle className="dot4" id="fourdDot" cy={-r3} r="7" fill="#89735E" transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="255" to="255" dur="0s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle className="dot4" cy={-r3} r="12" fill="#89735E" opacity="0.3" strokeWidth={strokeWidth} transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="255" to="255" dur="0s" repeatCount="indefinite"></animateTransform>
                        </circle>
                        <circle className="dot4" r={14} cy={-r3} data-radius="14" stroke="#89735E" opacity="0.3" strokeWidth="1" transform="rotate(0)">
                            <animateTransform attributeName="transform" attributeType="XML" type="rotate" from="255" to="255" dur="0s" repeatCount="indefinite"></animateTransform>
                            <animate attributeName="r" values="4;36;" dur="6s" repeatCount="indefinite"></animate>
                            <animate attributeName="stroke" values="#89735E;transparent" dur="6s" repeatCount="indefinite"></animate>
                        </circle>
                    </g>
                </svg>
            </div>
            <div className={clsx(
                "absolute top-0 z-[0] w-full h-full",
                "px-[34px]",
                "md:px-[24px]",
                "sm:px-[24px]",
                "xs:hidden"
            )}>
                <BgPin />
            </div>
        </div>
    );
};

export default App;
