import clsx from "clsx";
import useWindowSize from "../../../../hooks/useWindowSize";
import SpringText from "../../../../components/SpringText";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

const Genesis = () => {
    const { isMobile } = useWindowSize();

    // build with us
    const handleBuild = () => {
        console.log("Build With Us");
    }

    return (
        <div className="genesis-container relative w-full h-full flex items-center xs:items-end">
            <div className={clsx(
                "relative z-[1] w-full h-full max-h-[48%] flex justify-between",
                "px-[120px]",
                "md:px-[80px]",
                "sm:px-[60px]",
                "xs:px-[16px]"
            )}>
                <div className={clsx(
                    "h-full flex flex-1 flex-col justify-between",
                    "sm:w-[100%]",
                    "xs:w-[100%]"
                )}>
                    <div className={clsx(
                        "flex flex-col gap-[72px]",
                        "sm:opacity-0 sm:hidden",
                        "xs:opacity-0 xs:hidden"
                    )}>
                        <div className={clsx(
                            "text-[18px] leading-[26px] flex flex-col",
                            "md:text-[16px]"
                        )}>
                            <SpringText text="Setting new standards for " />
                            <SpringText text="mass adoption in blockchain gaming" />
                        </div>
                        <div className="w-[12px] h-[12px] flex justify-center items-center bg-[#EB5504]">
                            <img src="/icons/arrow_down.svg" alt="arrow" />
                        </div>
                    </div>
                    <div className="main-title">
                        <div className="flex flex-col">
                            <div className={clsx(
                                "text-[82px] font-bold leading-[82px] flex flex-wrap font-BD_Regular",
                                "md:text-[72px] md:leading-[72px]",
                                "sm:text-[64px] sm:leading-[64px]",
                                "xs:text-[64px] xs:leading-[64px] xs:text-center xs:justify-center"
                            )}>
                                <SpringText text="Genesis " />
                                <SpringText text="your Verse" />
                            </div>
                        </div>
                        <div className={clsx(
                            "w-[70%] max-w-[732px] flex flex-col font-normal text-[20px] leading-[32px] mt-[18px]",
                            "md:w-[70%] text-[18px]",
                            "sm:w-[70%]",
                            "xs:w-[100%] xs:text-center xs:mt-[16px] xs:text-[14px] xs:leading-[26px]",
                        )}>
                            <div>
                                These worlds, designed with diegesis at their core, will not merely offer incremental improvements over existing experiences but will present entirely new affordances.
                            </div>
                        </div>
                        <div className={clsx(
                            "doc-btn hidden flex items-center justify-center cursor-pointer text-[#EAE3D5]",
                            "font-bold text-[12px] gap-[12px] w-[130px] h-[36px] leading-[16px]",
                            "rounded-[100px] bg-[#0F0E0D] hover:bg-[#432A25] relative overflow-hidden select-none",
                            " xs:flex xs:m-auto xs:mt-[24px] xs:!doc-btn"
                        )}
                            onClick={handleBuild}
                        >
                            <span>Build With Us</span>
                            <img className="h-full absolute right-0 bottom-0 z-[0]" src="/images/hover_btn_bg.svg" alt="btn_bg" />
                        </div>

                    </div>
                </div>
                <div className={clsx(
                    "h-full flex flex-col justify-between",
                    "sm:opacity-0 sm:hidden",
                    "xs:opacity-0 xs:hidden"
                )}>
                    <div className="flex flex-col gap-[90px]">
                        <div className="">
                            <div className="mb-[10px]">
                                <img className="w-[86px] object-cover" src="/icons/VersE.svg" alt="verse" />
                            </div>
                            <div className="w-[60px] h-[20px] flex justify-end items-center bg-[#EB5504] px-[4px]">
                                <img className="-rotate-90" src="/icons/arrow_down.svg" alt="arrow" />
                            </div>
                        </div>
                        <div className={clsx(
                            "text-[18px] leading-[26px] flex flex-col",
                            "md:text-[16px]"
                        )}>
                            <SpringText text="Pioneering the gaming blockchain on " />
                            <SpringText text="Cosmos with EVM or any-VM compatibility." />
                            <img className="w-[176px] mt-[12px]" src="/images/home/home_line.svg" alt="line" />
                        </div>
                    </div>
                    <div className={clsx(
                        "text-[18px] leading-[26px] flex flex-col mb-[10px]",
                        "md:text-[16px]"
                    )}>
                        <SpringText text="Setting new standards for " />
                        <SpringText text="mass adoption in blockchain gaming" />
                    </div>
                </div>
            </div>
            <div className={clsx(
                "absolute z-[1] bottom-[54px] w-full flex flex-wrap items-center gap-[300px]",
                "px-[120px]",
                "md:px-[80px]",
                "sm:px-[60px]",
                "xs:hidden"
            )}>
                <div className="text-[12px] font-bold leading-[16px] text-[#FF5C01] text-uppercase">GENESIS-</div>
                <div className="flex flex-wrap gap-[48px] text-[12px] font-bold leading-[16px] text-[#262626] opacity-[0.7]">
                    <p>READ-</p>
                    <p>WRITE-</p>
                    <p>OWN-</p>
                </div>
            </div>
            <div className="w-full h-full absolute top-0 left-0 w-full z-[0] overflow-hidden">
                {
                    isMobile ?
                        <img src="/video/banner_web_m.webp" className="w-full h-full object-cover absolute top-[-16vh]" />
                        :
                        <video src={"/video/banner_web.mp4"} className="w-full h-full object-cover object-center absolute top-0 left-0" autoPlay muted loop />
                }
                <img src={isMobile ? "/images/home/video_modal_m.png" : "/images/home/video_modal.png"} className="absolute bottom-0 left-0 w-full h-full object-cover" />
            </div>
        </div>
    )
};

export default Genesis;
