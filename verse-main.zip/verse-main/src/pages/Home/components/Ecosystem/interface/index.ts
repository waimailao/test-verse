export interface cardItemProps {
  icon: string;
  title: string;
  summary: string;
  keyword: any[];
}