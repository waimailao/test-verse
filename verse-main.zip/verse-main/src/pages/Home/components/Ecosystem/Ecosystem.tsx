import clsx from "clsx";
import "./ecosystem.css";
import { useState } from "react";
import BgPin from "../../../../components/BgPin";
import CircleSvg from "../../../../components/CircleSvg";
import SpringText from "../../../../components/SpringText";
import infoJson from "./json/info.json";
import SlickScroll from "./components/SlickScroll";
import { cardItemProps } from "./interface";
import useWindowSize from "../../../../hooks/useWindowSize";

const Ecosystem = () => {
    const { isMobile } = useWindowSize();

    const [list] = useState<cardItemProps[]>(infoJson);

    return <div className="ecosystem-container common-bg relative w-full h-full flex items-center">
        <div className={clsx(
            "relative z-[2] w-full h-full flex flex-col gap-[20px] justify-center",
            "px-[120px]",
            "md:px-[80px]",
            "sm:px-[60px]",
            "xs:px-[0]"
        )}>
            <div className={clsx(
                "text-[80px] font-bold leading-1 font-BD_Regular",
                "xs:text-[32px]"
            )}>
                <SpringText text="Ecosystem" center />
            </div>
            <div className={clsx(
                "flex flex-col gap-[4px] text-[16px] leading-[24px] w-[40%] mx-auto text-[#0F0E0D]/60",
                "xs:text-[12px] xs:w-[90%]"
            )}>
                <SpringText text="Here is a description copy，Here is a description " center />
                <SpringText text="copy，Here is a description copy" center />
            </div>

            <div className="w-full flex flex-col gap-[12px] overflow-hidden relative mt-[20px]">
                <div className="absolute left-[-120px] top-0 h-full w-auto z-[10] xs:hidden">
                    <img className="h-full w-auto object-cover" src="/images/home/left_modal.png" alt="left-modal" />
                </div>
                <div className="absolute right-[-120px] top-0 h-full w-auto z-[10] xs:hidden">
                    <img className="h-full w-auto object-cover" src="/images/home/right_modal.png" alt="right-modal" />
                </div>
                <SlickScroll list={list.slice(0, 5)}></SlickScroll>
                <SlickScroll list={list.slice(5)} options={{ direction: "right" }}></SlickScroll>
            </div>
        </div>
        {
            !isMobile && <div className={clsx(
                "absolute top-0 z-[1] w-full h-full",
                "px-[34px]",
                "md:px-[24px]",
                "sm:px-[24px]",
                "xs:hidden"
            )}>
                <CircleSvg />
            </div>
        }
        <div className={clsx(
            "absolute top-0 z-[0] w-full h-full",
            "px-[34px]",
            "md:px-[24px]",
            "sm:px-[24px]",
            "xs:hidden"
        )}>
            <BgPin />
        </div>
    </div>
};

export default Ecosystem;
