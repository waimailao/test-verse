import clsx from "clsx";
import "./cardItem.css";

const CardItem = ({ data }: { data: any }) => {
  return (
    <div className={clsx(
      "card-item flex flex-col justify-evenly flex-none w-[360px] h-[240px] gap-[12px] box-border border border-[#0F0E0D]/20 rounded-[8px] bg-[#13090005] p-[30px]",
      "xs:w-[330px] xs:h-[220px] xs:p-[20px]"
    )}>
      <div className="w-[48px] h-[48px]">
        <img className="w-full h-full object-cover" src={`/icons/ecosystem/${data.icon}.svg`} alt="icon" />
      </div>
      <div className="text-[20px] font-bold">{data.title}</div>
      <div className="text-[12px]">{data.summary}</div>
      <div className="flex gap-[8px]">
        {
          data.keyword.map((word: any) => {
            return <span className="text-[12px] border border-[#0F0E0D] rounded-[20px] px-[12px]" key={word.name}>{word.name}</span>
          })
        }
      </div>
    </div>
  );
};

export default CardItem;
