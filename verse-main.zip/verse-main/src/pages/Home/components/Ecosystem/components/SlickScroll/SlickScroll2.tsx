import { useRef } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import CardItem from "../cardItem/CardItem";
import { cardItemProps } from "../../interface";
import "./slickScroll.css";

function AutoPlay({ list, options }: { list: cardItemProps[], options?: any }) {
    const sliderRef = useRef();

    const settings = {
        dots: false,
        arrows: false,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        speed: 3000,
        autoplaySpeed: 0,
        cssEase: "linear",
        variableWidth: true,
        pauseOnHover: false,
        pauseOnFocus: false,
        ...options
    };

    return (
        <>
            <Slider ref={sliderRef} {...settings} className="slider-container ecosystem-slider">
                {
                    list.slice(0, 5).map((data: cardItemProps) => {
                        return (
                            <CardItem data={data} key={data.icon + data.title} />
                        )
                    })
                }
            </Slider>
        </>
    );
}

export default AutoPlay;
