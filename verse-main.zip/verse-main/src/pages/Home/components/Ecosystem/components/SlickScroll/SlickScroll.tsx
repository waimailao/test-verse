import { useRef } from "react";
import Marquee from "react-fast-marquee";
import CardItem from "../cardItem/CardItem";
import { cardItemProps } from "../../interface";
import "./slickScroll.css";

function AutoPlay({ list, options }: { list: cardItemProps[], options?: any }) {
    const sliderRef = useRef();

    const settings = {
        autoFill: true,
        pauseOnHover: true,
        ...options
    };

    return (
        <>
            <Marquee ref={sliderRef} {...settings} className="slider-container ecosystem-slider">
                {
                    list.slice(0, 5).map((data: cardItemProps) => {
                        return (
                            <CardItem data={data} key={data.icon + data.title} />
                        )
                    })
                }
            </Marquee>
        </>
    );
}

export default AutoPlay;
