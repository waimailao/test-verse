import { createContext, useContext, useState } from 'react';
import gsap from 'gsap';

interface GSAPContextType {
  gsapInstance: typeof gsap;
}

export const GSAPContext = createContext<GSAPContextType>({
  gsapInstance: gsap,
});

export const useGSAPContext = () => useContext(GSAPContext);

export const GSAPProvider = ({ children }: { children: any }) => {
  const [gsapInstanceRef] = useState<typeof gsap>(gsap);

  const value = { gsapInstance: gsapInstanceRef };
  return <GSAPContext.Provider value={value}>{children}</GSAPContext.Provider>;
};
