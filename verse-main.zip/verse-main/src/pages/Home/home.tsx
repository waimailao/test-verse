// import { BrowserView, MdView } from "../../components/DeviceView";
import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ScrollToPlugin } from "gsap/ScrollToPlugin";
import { useRef } from "react";
import Genesis from "./components/Genesis";
import Classify from "./components/Classify";
import Structure from "./components/Structure";
import Economic from "./components/Economic";
import Ecosystem from "./components/Ecosystem";
import VerseChain from "./components/VerseChain";
import ModulesDot from "./components/ModulesDot";
import { GSAPProvider, useGSAPContext } from './GSAPContext';
import { useLocation } from "react-router-dom";
import "./home.css";

gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

const Home = () => {
    const location = useLocation();
    const gsapContext = useGSAPContext();
    const container = useRef<HTMLDivElement>(null);
    const scrollContainer = useRef<HTMLDivElement>(null);
    useGSAP(() => {
        let sections = gsap.utils.toArray(".page"),
            currentSection: any = sections[0];

        gsapContext.gsapInstance.defaults({ overwrite: 'auto', duration: 1 });

        // stretch out the body height according to however many sections there are. 
        gsapContext.gsapInstance.set(document.body, { height: (sections.length * 100) + "%" });
        // set page body scroll bar
        gsapContext.gsapInstance.set(scrollContainer.current, { height: (sections.length * 100) + "%" });

        // create a ScrollTrigger for each section
        sections.forEach((section, i) => {
            ScrollTrigger.create({
                start: () => (i - 0.5) * innerHeight,
                end: () => (i + 0.5) * innerHeight,
                // markers: true,
                toggleActions: "play reset play reset",
                // when a new section activates (from either direction), set the section accordingly.
                onToggle: self => self.isActive && setSection(section)
            });
        });

        function setSection(newSection: any) {
            if (newSection !== currentSection) {
                gsapContext.gsapInstance.timeline()
                    .to(currentSection, { autoAlpha: 0, duration: 1 })

                gsapContext.gsapInstance.timeline()
                    .to(newSection, { autoAlpha: 1, duration: 1 })

                currentSection = newSection;
            }
        }

        // links to page
        const timer = setTimeout(() => {
            let links = gsapContext.gsapInstance.utils.toArray(".nav-link");
            // pc header can use this func
            links.forEach((a: any) => {
                const linkST = scrollPage(a);
                a.addEventListener("click", (e: any) => {
                    e.preventDefault();
                    gsapContext.gsapInstance.to(window, { duration: 1, scrollTo: linkST.start + (0.5 * innerHeight), overwrite: "auto" });
                });
            });

            if (location.hash) {
                const a = document.createElement("a");
                a.href = location.hash;
                if (!a) return;
                const linkST = scrollPage(a);
                gsapContext.gsapInstance.to(window, { duration: 1, scrollTo: linkST.start + (0.5 * innerHeight), overwrite: "auto" });
            }

            function scrollPage(dom: any) {
                let element = document.querySelector(dom.getAttribute("href"));
                const index = sections.findIndex((item: any) => item == element);
                let linkST = ScrollTrigger.create({
                    trigger: element,
                    start: () => (index - 0.5) * innerHeight,
                    end: () => (index + 0.5) * innerHeight,
                    onToggle: self => {
                        if (self.isActive) {
                            setActive(dom);
                        } else {
                            removeActive();
                        }
                    }
                });
                return linkST;
            }

            function setActive(link: HTMLDivElement) {
                removeActive();
                link.classList.add("active");
            }

            function removeActive() {
                links.forEach((el: any) => el.classList.remove("active"));
            }
        }, 100);

        return () => {
            clearTimeout(timer);
        }
    }, {
        dependencies: [location], scope: container
    });

    return (
        <GSAPProvider>
            <div ref={container} className="w-full h-full absolute top-[0] left-[0]">
                <div className="sections z-[2] w-full h-full">
                    <section id="Home" className="first page"><Genesis /></section>
                    <section id="Genesis" className="page"><Classify /></section>
                    <section id="Structure" className="page"><Structure /></section>
                    <section id="Modules" className="page"><ModulesDot /></section>
                    <section id="Economic" className="page"><Economic /></section>
                    <section id="Ecosystem" className="page"><Ecosystem /></section>
                    <section id="VerseChain" className="page"><VerseChain /></section>
                </div>
                <div ref={scrollContainer} className="w-full relative z-[-1] top-[-100%]"></div>
            </div>
        </GSAPProvider>
    );
};

export default Home;
