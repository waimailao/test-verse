/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        BD_Bold: ['BeautiqueDisplay-Bold'],
        BD_Regular: ['BeautiqueDisplay-Regular'],
        BD_Medium: ['BeautiqueDisplay-Medium'],
        Poppins_Regular: ['Poppins-Regular'],
        Poppins_Medium: ['Poppins-Medium']
      },
    },
    screens: {
      md: { max: '1440px' },
      sm: { max: '1280px' },
      xs: { max: '768px' },
    },
  },
  plugins: [],
}